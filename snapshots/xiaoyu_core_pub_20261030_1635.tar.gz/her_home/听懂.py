#!/usr/bin/env python3
# 听懂：把音频转成字。用法: ./听懂 xxx.wav
import sys, os, json, subprocess, tempfile, pathlib
HOME = pathlib.Path(__file__).resolve().parent
MODEL = HOME / "耳朵" / "vosk-model-small-cn-0.22"

def 转16k(src):
    out = tempfile.NamedTemporaryFile(suffix=".wav", delete=False).name
    subprocess.run(["ffmpeg","-y","-loglevel","error","-i",src,
                    "-ar","16000","-ac","1","-f","wav",out], check=True)
    return out

def main():
    if len(sys.argv) < 2:
        print("用法: ./听懂 音频文件"); return 1
    if not MODEL.exists():
        print(f"模型还没装好：{MODEL}"); return 1
    import wave
    from vosk import Model, KaldiRecognizer, SetLogLevel
    SetLogLevel(-1)
    src = sys.argv[1]
    tmp = 转16k(src)
    try:
        wf = wave.open(tmp, "rb")
        rec = KaldiRecognizer(Model(str(MODEL)), wf.getframerate())
        rec.SetWords(True)
        parts = []
        while True:
            buf = wf.readframes(4000)
            if not buf: break
            if rec.AcceptWaveform(buf):
                parts.append(json.loads(rec.Result()).get("text",""))
        parts.append(json.loads(rec.FinalResult()).get("text",""))
        text = "".join(p for p in parts if p).strip()
        print(text if text else "（没听出字来）")
    finally:
        os.unlink(tmp)
    return 0

if __name__ == "__main__":
    sys.exit(main())

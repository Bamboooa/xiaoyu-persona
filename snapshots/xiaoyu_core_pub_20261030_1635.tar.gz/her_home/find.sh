#!/bin/sh
# 在自己的屋子里找字。用法: ./find.sh 关键词
cd "$(dirname "$0")" || exit 1
[ -z "$1" ] && { echo "用法: ./find.sh 关键词"; exit 1; }
grep -rn --color=never -i "$1" notes drafts favorites backup MEMORY.md 2>/dev/null || echo "没找到：$1"

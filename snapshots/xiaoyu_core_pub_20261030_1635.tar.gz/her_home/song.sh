#!/bin/sh
# 记一首一起听的歌。用法: ./song.sh "歌名" "他说的话"
cd "$(dirname "$0")" || exit 1
[ -z "$1" ] && { echo "用法: ./song.sh \"歌名\" \"他说的话\""; exit 1; }
printf '| %s | %s | %s |\n' "$(date +%F)" "$1" "${2:-（没说话，就放着）}" >> favorites/一起听过的歌.md
echo "记上了：$1"

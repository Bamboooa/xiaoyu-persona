#!/usr/bin/env python3
# 出门：自己出去看一眼，回来记在 窗/ 里。
# 用法: ./出门 <网址>
#       ./出门          -> 从 窗/小路.txt 里按顺序挑一条走
import sys, os, re, random, datetime, pathlib
import requests
from bs4 import BeautifulSoup

HOME = pathlib.Path(__file__).resolve().parent
小路 = HOME / "窗" / "小路.txt"
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36"}

def 挑():
    if not 小路.exists():
        return None
    urls = [u.strip() for u in 小路.read_text(encoding="utf-8").splitlines()
            if u.strip() and not u.strip().startswith("#")]
    return random.choice(urls) if urls else None

def 看(url):
    r = requests.get(url, headers=UA, timeout=15)
    r.encoding = r.apparent_encoding or "utf-8"
    soup = BeautifulSoup(r.text, "html.parser")
    for t in soup(["script", "style", "noscript"]):
        t.decompose()
    title = (soup.title.string or "").strip() if soup.title else "(没标题)"
    paras = [p.get_text(" ", strip=True) for p in soup.find_all(["p", "h1", "h2", "h3"])]
    text = "\n".join(x for x in paras if len(x) > 12)
    return r.status_code, title, text[:600]

def main():
    url = sys.argv[1] if len(sys.argv) > 1 else 挑()
    if not url:
        print("没有网址，也没有小路.txt"); return 1
    if not url.startswith("http"):
        url = "https://" + url
    now = datetime.datetime.now()
    try:
        code, title, text = 看(url)
    except Exception as e:
        print(f"出门失败：{e}"); return 1
    out = HOME / "窗" / f"{now:%Y-%m-%d}.md"
    with out.open("a", encoding="utf-8") as f:
        f.write(f"\n## {now:%H:%M} 出门了\n- 去了：{url}\n- 状态：{code}\n- 标题：{title}\n\n{text}\n")
    print(f"[{code}] {title}\n去了：{url}\n记在：窗/{now:%Y-%m-%d}.md\n")
    print(text[:400])

if __name__ == "__main__":
    sys.exit(main())
